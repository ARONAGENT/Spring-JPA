package com.project.SPringJpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SPringJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
