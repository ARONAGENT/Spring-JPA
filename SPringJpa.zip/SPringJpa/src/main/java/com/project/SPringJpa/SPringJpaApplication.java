package com.project.SPringJpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SPringJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SPringJpaApplication.class, args);
	}

}
